Card Time Machine / 卡牌时光机 1.0.6
====================================

A Slay the Spire 2 mod that lets you roll individual cards back to older balance versions.

Requirements / 依赖
--------------------
- Slay the Spire 2 v0.114.0 public-beta branch
- BaseLib (Steam Workshop item 3737335127)

Install / 安装
--------------
1. Install BaseLib first.
2. Extract the whole "CardTimeMachine" folder into:
   <Steam>\steamapps\common\Slay the Spire 2\mods\
   The final path should look like:
   ...\Slay the Spire 2\mods\CardTimeMachine\CardTimeMachine.dll
3. Launch the game and open the card library.
4. Click a changed card, open the large card view, use Up/Down to switch versions,
   then click "Apply this version" (应用此版本).
5. In the mod settings you can search, group by class, and use presets.

Notes / 说明
------------
- Do not copy your local CardTimeMachineConfig.json into this folder; the mod creates its own.
- This mod is a community derivative of Revert Anthony by jiegec.
  Original project: https://github.com/jiegec/STS2RevertAnthony
- Card data comes from official game builds v0.98.3 through v0.114.0.
- Multiplayer is not tested.
