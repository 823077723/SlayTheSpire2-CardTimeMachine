Card Time Machine / 卡牌时光机 1.2.1 (EXPERIMENTAL / 实验版)
================================================================

A Slay the Spire 2 mod that lets you roll individual cards back to older
balance versions, and optionally exclude cards from the card pool.

This 1.2.1 build is an EXPERIMENTAL preview.
The stable release is still 1.0.6.

Requirements / 依赖
-------------------
- Slay the Spire 2 v0.114.0 public-beta branch
  (NOT compatible with the v0.111.1 public branch: that build lacks the
   Fool cards and several Power types used by this DLL.)
- BaseLib (Steam Workshop item 3737335127)

Install / 安装
--------------
1. Install BaseLib first.
2. Extract the whole "CardTimeMachine" folder into:
   <Steam>\steamapps\common\Slay the Spire 2\mods\
   The final path should look like:
   ...\Slay the Spire 2\mods\CardTimeMachine\CardTimeMachine.dll
3. Launch the game and open the card library.

What's new in 1.2.1 / 1.2.1 新增
--------------------------------
- Card-pool exclusion / 卡池排除:
  In the card library detail view, use "排除此卡" (Exclude this card) to stop
  the card from appearing in future rewards, shops and random generation.
  Every card can be excluded, including cards that have no older version.
- Preset bans / 预设排除表:
  "Save preset" now stores both card versions and the exclusion list.
- Fixed the oversized "Save preset" dialog.

Notes / 说明
------------
- Card-pool exclusion is a soft ban: it does not delete the card, and cards
  already in your deck/save remain. A few hard-coded events/relics/starting
  decks may still create the card.
- The dev console "card <ID>" can still add an excluded card.
- This experimental build has not been fully regression-tested. Back up your
  saves, and switch back to 1.0.6 if anything feels wrong.
- Do not copy your local CardTimeMachineConfig.json into this folder; the mod
  creates its own.
- This mod is a community derivative of Revert Anthony by jiegec.
  Original project: https://github.com/jiegec/STS2RevertAnthony
- Card data comes from official game builds v0.98.3 through v0.114.0.
- Multiplayer is not tested.
